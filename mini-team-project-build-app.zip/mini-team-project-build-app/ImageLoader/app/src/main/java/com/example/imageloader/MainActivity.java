package com.example.imageloader;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{
    Button loadImageBtn;
    ImageView imageView;
    ActivityResultLauncher<String> mGetContent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadImageBtn =  findViewById(R.id.loadImageBtn);
        imageView = findViewById(R.id.imageView);

        mGetContent=registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri result) {
                imageView.setImageURI(result);
            }
        });

        loadImageBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                        mGetContent.launch("image/*");
            }
        });

    }


}